N=100;                % Liczba definiowanych punkt�w czasowych
n=5;                  % Liczba sinusoid sk�adowych do aproks.
t=[0:2*pi/N:2*pi*(N-1)/N]';
y=sawtooth(t);        % Zadany kszta�t pi�okszta�tny
U=sin(t*[1:n])*sqrt(2/N);
a=U'*y;
plot(t,y,'r.',t,U*a)